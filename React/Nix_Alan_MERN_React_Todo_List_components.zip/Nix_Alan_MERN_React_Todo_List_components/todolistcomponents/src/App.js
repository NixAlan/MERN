import './App.css';
import React, {useState} from 'react';
import Dispalylist from './Components/Displaylist';
import Form from './Components/form';

function App() {
const [taskDesc, setTaskDesc] = useState("Enter Task")
const [taskArr, setTaskarr] = useState([])

const submitHandler = (e) => {
  e.preventDefault();
  const newTask = {
    taskDesc: taskDesc,
    isComplete: 'none'
  }
  setTaskarr([...taskArr, newTask])
  setTaskDesc("")
  
}

const handleCheckBox = (index) => {
  let updateCheckBox = {...taskArr[index]}

if(updateCheckBox.isComplete === 'none'){
  updateCheckBox.isComplete = 'line-through'
  
}else{
  updateCheckBox.isComplete = 'none'
  }
  setTaskarr(
    [...taskArr.slice(0,index), updateCheckBox].concat(taskArr.slice(index+1))
  )
}

const handleDelete = (e,indexFromBelow) => {
  // e.preventDefault();
  const filteredArr = taskArr.filter((element,index)=> index !== indexFromBelow);
  setTaskarr(filteredArr)
}


  return (
    <div className="App">
      <Form
      submitHandler = {submitHandler}
      taskDesc = {taskDesc}
      setTaskDesc = {setTaskDesc}
      />
      <Dispalylist 
      taskArr={taskArr}
      handleCheckBox={handleCheckBox}
      handleDelete={handleDelete}
      />
  </div>

)  
}

export default App;
