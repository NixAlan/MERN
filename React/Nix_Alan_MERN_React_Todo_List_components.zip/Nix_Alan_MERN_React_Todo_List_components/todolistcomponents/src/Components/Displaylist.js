import React, {useState} from "react";

const Dispalylist = (props) => {
  const {taskArr, handleCheckBox, handleDelete} = props;
  return(
    <ul>
        { 
          taskArr.map((element,index) => {
            return(
              <div key={index}>
              <li>
                  <div className='rowWrapper'>
                    <p style={{
                      textDecoration: `${element.isComplete}`
                    }}>{element.taskDesc}</p>
                    <input type="checkbox" checked={
                      element.isComplete === 'none' ? false : true
                    } onChange={() => handleCheckBox(index)}></input>
                    <button onClick={(e) => handleDelete(e,index)}
                    style={{backgroundColor: 'black', color: 'white',width: 75}}>Delete</button>
                  </div> 
                </li>
                </div>
      )}
          )
            }
</ul>
  )


}

export default Dispalylist;