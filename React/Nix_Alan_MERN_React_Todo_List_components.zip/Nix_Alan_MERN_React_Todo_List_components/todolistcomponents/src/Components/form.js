import React, {useState} from "react";

const Form = (props) => {
    const{submitHandler,taskDesc,setTaskDesc} = props;
    return(
<form onSubmit={(e) => submitHandler(e)}>
      <input type="text" 
      value={taskDesc}
      onChange={(e)=>{
        setTaskDesc(e.target.value)
      }} />
      <button style={{backgroundColor: 'blue', color: 'white'}} >ADD</button>
      </form>
    )
}

export default Form