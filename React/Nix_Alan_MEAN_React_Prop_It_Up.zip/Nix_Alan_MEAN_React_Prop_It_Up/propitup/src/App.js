
import './App.css';
import PersonCard from './Components/PersonCard';

function App() {
  return (
    <div className="App">
      <PersonCard
      lastname={"Doe"}
      firstname={"Jane"}
      age={45}
      hair={"Black"}
      />
      <PersonCard
      lastname={"Smith"}
      firstname={"John"}
      age={88}
      hair={"Brown"}
      />
      <PersonCard
      lastname={"Fillmore"}
      firstname={"Millard"}
      age={50}
      hair={"Brown"}
      />
      <PersonCard
      lastname={"Smith"}
      firstname={"Maria"}
      age={62}
      hair={"Brown"}
      />
      </div>
  );
}

export default App;
