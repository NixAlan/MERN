import react, {useState} from 'react'

const PersonCard = (props) => {
    const[birthday, setBirthday] = useState(props.age)
    return  (
        <div className='Personcardboxwrapper'>
            <h1> {props.lastname}, {props.firstname}</h1>
            <p>Age: {birthday}</p>
            <p>Hair Color: {props.hair}</p>
            <button onClick = { (event) => setBirthday(birthday + 1) }>Set Birthday</button>
        </div>
    )
}

export default PersonCard